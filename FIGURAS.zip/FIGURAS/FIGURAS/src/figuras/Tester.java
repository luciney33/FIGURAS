package figuras;

public class Tester {
    public static void main(String[] args) {
        System.out.println("=== Prueba de la clase Triángulo ===");
        Triangulo triangulo = new Triangulo();
        System.out.println("Lados del triángulo: " + triangulo.getLado1() + ", " + triangulo.getLado2() + ", " + triangulo.getLado3());
        System.out.println("Perímetro del triángulo: " + triangulo.calcularPerimetro());
        triangulo.calcularArea();

        System.out.println("\n=== Prueba de la clase Círculo ===");
        Circulo circulo = new Circulo();
        System.out.println("Radio del círculo: " + circulo.getRadio());
        System.out.println("Área del círculo: " + circulo.calcularArea());
        System.out.println("Perímetro del círculo: " + circulo.calcularPerimetro());

        System.out.println("\n=== Prueba de la clase Cuadrado ===");
        Cuadrado cuadrado = new Cuadrado();
        System.out.println("Lado del cuadrado: " + cuadrado.getLado());
        System.out.println("Área del cuadrado: " + cuadrado.calcularArea());
        System.out.println("Perímetro del cuadrado: " + cuadrado.calcularPerimetro());
    }
}
