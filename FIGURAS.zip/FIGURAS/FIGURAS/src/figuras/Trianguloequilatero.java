package figuras;

public class Trianguloequilatero extends Figuras{
    private int lado;
    public Trianguloequilatero() {
        this.lado = 3;

    }
    public Trianguloequilatero(int lado1, int lado2, int lado3){
        this.lado = lado1;

    }
    public double getLado1() {
        return lado;
    }
    public void setLado1(int lado1) {
        this.lado = lado1;
    }

    public double calcularPerimetro(){
        return lado;

    }
    public void calcularArea(){
        double semiPerimetro = calcularPerimetro() /2;
        double area = Math.sqrt(semiPerimetro*(semiPerimetro-lado));
        System.out.println("Área del triángulo equilatero: " + area);
    }
}