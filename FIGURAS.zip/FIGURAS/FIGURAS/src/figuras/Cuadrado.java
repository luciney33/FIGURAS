package figuras;

public class Cuadrado extends Figuras {
    private double lado;
    public Cuadrado() {
        this.lado = 5;
    }
    public Cuadrado(double lado) {
        this.lado = lado;
    }
    public double getLado() {
        return lado;
    }
    public void setLado(double lado) {
        this.lado = lado;
    }
    public double calcularArea() {
        return lado * lado;
    }
    public double calcularPerimetro() {
        return 4 * lado;
    }
}
