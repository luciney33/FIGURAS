package figuras;

public abstract class Figuras {

}
