package figuras;

public class Trianguloequilatero {
    private int lado1;
    public Trianguloequilatero() {
        this.lado1 = 3;

    }
    public Trianguloequilatero(int lado1, int lado2, int lado3){
        this.lado1 = lado1;

    }
    public double getLado1() {
        return lado1;
    }
    public void setLado1(int lado1) {
        this.lado1 = lado1;
    }

    public double calcularPerimetro(){
        return lado1;

    }
    public void calcularArea(){
        double semiPerimetro = calcularPerimetro() /2;
        double area = Math.sqrt(semiPerimetro*(semiPerimetro-lado1));
        System.out.println("Área del triángulo: " + area);
    }
}